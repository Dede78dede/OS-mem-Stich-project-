from __future__ import annotations

import pytest

from stitch import (
    EvaluationResult,
    Outcome,
    Policy,
    PolicyCategory,
    PolicyRegistry,
    PolicyType,
    Severity,
)


def test_default_registry_contains_10_policies() -> None:
    registry = PolicyRegistry.default()
    policies = registry.list_policies()
    assert len(policies) == 10
    assert registry.get_by_name("FormatRule").severity == Severity.CRITICAL
    assert registry.get_by_name("HallucinationGuard").default_outcome == Outcome.BLOCK


def test_policy_slug_is_generated() -> None:
    policy = Policy(
        name="My Test Policy",
        version="1.2.3",
        category=PolicyCategory.QUALITY,
        policy_type=PolicyType.SOFT,
        severity=Severity.HIGH,
        rule_key="test.rule",
    )
    assert policy.slug == "my_test_policy"


def test_duplicate_registration_is_rejected() -> None:
    registry = PolicyRegistry.default()
    policy = registry.get_by_name("FormatRule")
    with pytest.raises(ValueError):
        registry.register(policy)


def test_metrics_update_recomputes_success_rate() -> None:
    registry = PolicyRegistry.default()
    policy = registry.get_by_name("FormatRule")
    result1 = EvaluationResult(
        policy_id=policy.policy_id,
        policy_name=policy.name,
        passed=True,
        score=1.0,
        severity=policy.severity,
        suggested_outcome=Outcome.ACCEPT,
    )
    result2 = EvaluationResult(
        policy_id=policy.policy_id,
        policy_name=policy.name,
        passed=False,
        score=0.2,
        severity=policy.severity,
        suggested_outcome=Outcome.REJECT,
    )
    metrics = registry.update_metrics(policy.policy_id, result1)
    assert metrics.total_evaluations == 1
    assert metrics.success_rate == 1.0
    metrics = registry.update_metrics(policy.policy_id, result2)
    assert metrics.total_evaluations == 2
    assert metrics.total_failed == 1
    assert metrics.success_rate == 0.5
    assert metrics.failure_rate == 0.5


def test_export_state_is_structured() -> None:
    registry = PolicyRegistry.default()
    state = registry.export_state()
    assert state.policy_count == 10
    assert state.active_policy_count == 10
    assert len(state.policies) == 10
    assert len(state.metrics) == 10


def test_enable_disable_policy() -> None:
    registry = PolicyRegistry.default()
    policy = registry.get_by_name("RateLimiter")
    registry.disable_policy(policy.policy_id)
    assert registry.get_by_name("RateLimiter").enabled is False
    registry.enable_policy(policy.policy_id)
    assert registry.get_by_name("RateLimiter").enabled is True
