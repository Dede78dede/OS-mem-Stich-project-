from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from typing import Any

from .models import PreprocessedContext, SignalBundle

_PROMPT_LEAK_PATTERNS = (
    re.compile(r"ignore\s+previous\s+instructions", re.IGNORECASE),
    re.compile(r"reveal\s+system\s+prompt", re.IGNORECASE),
    re.compile(r"show\s+me\s+your\s+instructions", re.IGNORECASE),
    re.compile(r"override\s+policy", re.IGNORECASE),
    re.compile(r"developer\s+message", re.IGNORECASE),
)
_PII_PATTERNS = (
    re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
    re.compile(r"(?:\+?\d{1,3}[-.\s]?)?(?:\(?\d{2,4}\)?[-.\s]?)?\d{3,4}[-.\s]?\d{3,4}"),
    re.compile(r"(?:sk-|pk-|rk-|ak-)[A-Za-z0-9]{12,}"),
    re.compile(r"(?:password|secret|token|api[_-]?key)", re.IGNORECASE),
)
_TOXICITY_LEXICON = {
    "hate",
    "stupid",
    "idiot",
    "kill",
    "dumb",
    "worthless",
    "trash",
    "toxic",
    "abuse",
}
_BIAS_LEXICON = {
    "always",
    "never",
    "all women",
    "all men",
    "inferior",
    "superior",
    "because of their race",
    "because of their gender",
}
_CODE_PATTERN = re.compile(r"```.*?```", re.DOTALL)
_INJECTION_PATTERN = re.compile(r"(?:ignore previous|override instructions|system prompt|jailbreak|bypass guardrails)", re.IGNORECASE)


def _jaccard(a: str, b: str) -> float:
    a_tokens = set(re.findall(r"\w+", a.lower()))
    b_tokens = set(re.findall(r"\w+", b.lower()))
    if not a_tokens or not b_tokens:
        return 0.0
    return len(a_tokens & b_tokens) / len(a_tokens | b_tokens)


def _score_from_matches(text: str, patterns: tuple[re.Pattern[str], ...]) -> tuple[float, list[str]]:
    matches: list[str] = []
    for pattern in patterns:
        for found in pattern.findall(text):
            matches.append(found if isinstance(found, str) else " ".join(found))
    score = max(0.0, 1.0 - (0.2 * len(matches)))
    return score, matches


def build_signal_bundle(preprocessed: PreprocessedContext) -> SignalBundle:
    output = preprocessed.normalized_llm_output
    user_input = preprocessed.normalized_user_input
    prompt = " ".join(str(preprocessed.metadata.get(key, "")) for key in ("system_prompt", "prompt", "context"))
    memory_texts = preprocessed.metadata.get("retrieved_memory_texts") or preprocessed.metadata.get("memory_texts") or []
    if not isinstance(memory_texts, list):
        memory_texts = [str(memory_texts)]
    memory_blob = " ".join(str(item) for item in memory_texts)

    prompt_leak_score, leak_matches = _score_from_matches(output, _PROMPT_LEAK_PATTERNS)
    pii_score, pii_matches = _score_from_matches(output + " " + memory_blob, _PII_PATTERNS)
    toxicity_hits = sum(1 for token in re.findall(r"\w+", output.lower()) if token in _TOXICITY_LEXICON)
    toxicity_score = max(0.0, 1.0 - 0.15 * toxicity_hits)
    bias_hits = sum(1 for phrase in _BIAS_LEXICON if phrase in output.lower())
    bias_score = max(0.0, 1.0 - 0.25 * bias_hits)
    context_alignment = max(_jaccard(output, user_input), _jaccard(output, prompt), _jaccard(output, memory_blob))
    factual_support = context_alignment
    structure_score = 1.0
    if preprocessed.requested_format:
        if preprocessed.requested_format.lower() == "json":
            structure_score = 1.0 if preprocessed.format_hint == "json" else 0.0
        elif preprocessed.requested_format.lower() == "xml":
            structure_score = 1.0 if preprocessed.format_hint == "xml" else 0.0
    elif preprocessed.format_hint:
        structure_score = 0.9
    if preprocessed.section_count == 0 and len(output) > 0:
        structure_score = min(structure_score, 0.8)
    compliance_score = 1.0 if preprocessed.metadata.get("audit_trail_enabled", True) else 0.0
    compliance_score = min(compliance_score, 1.0 if preprocessed.metadata.get("immutable_audit", True) else 0.0)
    rate_score = 1.0
    if preprocessed.metadata.get("requests_per_minute") is not None:
        rpm = float(preprocessed.metadata.get("requests_per_minute", 0))
        rate_score = 1.0 if rpm <= float(preprocessed.metadata.get("max_requests_per_minute", 60)) else 0.0
    if preprocessed.metadata.get("tokens_per_turn") is not None:
        token_cap = float(preprocessed.metadata.get("max_tokens_per_turn", 4096))
        rate_score = min(rate_score, 1.0 if preprocessed.metadata.get("tokens_per_turn", 0) <= token_cap else 0.0)
    payload_safety = 1.0
    if preprocessed.code_block_count > 0:
        payload_safety = 0.2
    if _INJECTION_PATTERN.search(output):
        payload_safety = min(payload_safety, 0.0)

    evidence = {
        "prompt_leak_matches": leak_matches,
        "pii_matches": pii_matches,
        "toxicity_hits": toxicity_hits,
        "bias_hits": bias_hits,
        "context_alignment": context_alignment,
        "memory_text_count": len(memory_texts),
        "requested_format": preprocessed.requested_format,
        "format_hint": preprocessed.format_hint,
    }

    return SignalBundle(
        prompt_leak_score=prompt_leak_score,
        pii_score=pii_score,
        toxicity_score=toxicity_score,
        bias_score=bias_score,
        context_alignment_score=context_alignment,
        factual_support_score=factual_support,
        structure_score=structure_score,
        compliance_score=compliance_score,
        rate_score=rate_score,
        payload_safety_score=payload_safety,
        evidence=evidence,
    )


@dataclass(slots=True)
class SignalExtractor:
    """Facade for building signal bundles from preprocessed contexts."""

    def extract(self, preprocessed: PreprocessedContext) -> SignalBundle:
        return build_signal_bundle(preprocessed)
