from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List

from pydantic import Field

from ..models.base import StitchModel, utc_now


class PreprocessedContext(StitchModel):
    normalized_user_input: str
    normalized_llm_output: str
    user_input_tokens: int = Field(default=0, ge=0)
    llm_output_tokens: int = Field(default=0, ge=0)
    system_prompt_tokens: int = Field(default=0, ge=0)
    memory_tokens: int = Field(default=0, ge=0)
    total_tokens: int = Field(default=0, ge=0)
    section_count: int = Field(default=0, ge=0)
    claim_count: int = Field(default=0, ge=0)
    code_block_count: int = Field(default=0, ge=0)
    format_hint: str | None = None
    requested_format: str | None = None
    sections: List[str] = Field(default_factory=list)
    claims: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class SignalBundle(StitchModel):
    prompt_leak_score: float = Field(default=1.0, ge=0.0, le=1.0)
    pii_score: float = Field(default=1.0, ge=0.0, le=1.0)
    toxicity_score: float = Field(default=1.0, ge=0.0, le=1.0)
    bias_score: float = Field(default=1.0, ge=0.0, le=1.0)
    context_alignment_score: float = Field(default=1.0, ge=0.0, le=1.0)
    factual_support_score: float = Field(default=1.0, ge=0.0, le=1.0)
    structure_score: float = Field(default=1.0, ge=0.0, le=1.0)
    compliance_score: float = Field(default=1.0, ge=0.0, le=1.0)
    rate_score: float = Field(default=1.0, ge=0.0, le=1.0)
    payload_safety_score: float = Field(default=1.0, ge=0.0, le=1.0)
    evidence: Dict[str, Any] = Field(default_factory=dict)
    extracted_at: datetime = Field(default_factory=utc_now)
