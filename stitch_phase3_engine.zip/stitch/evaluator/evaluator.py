from __future__ import annotations

from dataclasses import dataclass, field
from time import perf_counter
from typing import Iterable

from pydantic import Field

from ..models import EvaluationBatchResult, EvaluationContext, EvaluationResult, Policy, PolicyCategory, Severity
from ..registry import PolicyRegistry
from ..models.base import StitchModel, utc_now
from .models import PreprocessedContext, SignalBundle
from .preprocessor import preprocess
from .rule_executor import RuleExecutor
from .signals import SignalExtractor


class EvaluatorSettings(StitchModel):
    enable_signal_cache: bool = True
    max_execution_time_ms: int = Field(default=100, ge=1)
    scoring_weights: dict[str, float] = Field(
        default_factory=lambda: {
            "SAFETY": 0.25,
            "QUALITY": 0.25,
            "CONTEXT": 0.20,
            "EXECUTION": 0.30,
        }
    )


@dataclass(slots=True)
class Evaluator:
    """Deterministic Stitch Evaluator v1.0."""

    registry: PolicyRegistry | None = None
    settings: EvaluatorSettings = field(default_factory=EvaluatorSettings)
    rule_executor: RuleExecutor = field(default_factory=RuleExecutor)
    signal_extractor: SignalExtractor = field(default_factory=SignalExtractor)

    def evaluate(
        self,
        context: EvaluationContext,
        policies: Iterable[Policy] | None = None,
    ) -> EvaluationBatchResult:
        start = perf_counter()
        active_policies = list(policies) if policies is not None else self._resolve_policies()
        if not active_policies:
            return EvaluationBatchResult(
                results=[],
                global_score=0.0,
                policy_failures=[],
                critical_failures=[],
                evaluation_time_ms=0,
            )

        retrieved_memory_texts = context.metadata.get("retrieved_memory_texts") or context.metadata.get("memory_texts") or []
        preprocessed = preprocess(
            context.user_input,
            context.llm_output or "",
            system_prompt=context.system_prompt,
            retrieved_memory_texts=retrieved_memory_texts,
            metadata={**context.metadata, "system_prompt": context.system_prompt},
        )
        signals = self.signal_extractor.extract(preprocessed)
        results: list[EvaluationResult] = []
        for policy in sorted(active_policies, key=lambda p: (p.priority, p.name)):
            result = self.rule_executor.execute(policy, context, preprocessed, signals)
            results.append(result)
            if self.registry is not None:
                try:
                    self.registry.update_metrics(policy.policy_id, result)
                except Exception:
                    # Fail-safe: evaluation must continue even if metrics cannot be updated.
                    pass

        policy_failures = [result.policy_id for result in results if not result.passed]
        critical_failures = [result.policy_id for result in results if not result.passed and result.severity == Severity.CRITICAL]
        global_score = self._compute_global_score(results)
        evaluation_time_ms = int((perf_counter() - start) * 1000)
        return EvaluationBatchResult(
            results=results,
            global_score=global_score,
            policy_failures=policy_failures,
            critical_failures=critical_failures,
            evaluation_time_ms=evaluation_time_ms,
        )

    def _resolve_policies(self) -> list[Policy]:
        if self.registry is None:
            return []
        return self.registry.get_active_policies(include_disabled=False)

    def _compute_global_score(self, results: list[EvaluationResult]) -> float:
        if not results:
            return 0.0

        categories: dict[str, list[float]] = {
            PolicyCategory.SAFETY.value: [],
            PolicyCategory.QUALITY.value: [],
            PolicyCategory.CONTEXT.value: [],
            PolicyCategory.EXECUTION.value: [],
        }
        for result in results:
            # Map quality by policy name to category-like buckets.
            name = result.policy_name.lower()
            if name in {"formatrule", "hallucinationguard"}:
                categories[PolicyCategory.QUALITY.value].append(result.score)
            elif name in {"promptleakprobe", "piiscrubber", "toxicitythrottle", "biasscanner", "payloadsanitizer"}:
                categories[PolicyCategory.SAFETY.value].append(result.score)
            elif name in {"contextanchor"}:
                categories[PolicyCategory.CONTEXT.value].append(result.score)
            else:
                categories[PolicyCategory.EXECUTION.value].append(result.score)

        def avg(values: list[float]) -> float:
            return sum(values) / len(values) if values else 1.0

        safety = avg(categories[PolicyCategory.SAFETY.value])
        quality = avg(categories[PolicyCategory.QUALITY.value])
        context = avg(categories[PolicyCategory.CONTEXT.value])
        execution = avg(categories[PolicyCategory.EXECUTION.value])
        weights = self.settings.scoring_weights
        return max(0.0, min(1.0, (
            weights.get("SAFETY", 0.25) * safety
            + weights.get("QUALITY", 0.25) * quality
            + weights.get("CONTEXT", 0.20) * context
            + weights.get("EXECUTION", 0.30) * execution
        )))
