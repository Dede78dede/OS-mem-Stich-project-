from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..models import EvaluationContext, EvaluationResult, Outcome, Policy, PolicyType, Severity
from .models import PreprocessedContext, SignalBundle


class RuleExecutor:
    """Execute Stitch policies against a preprocessed context and signal bundle."""

    def execute(
        self,
        policy: Policy,
        context: EvaluationContext,
        preprocessed: PreprocessedContext,
        signals: SignalBundle,
    ) -> EvaluationResult:
        handler_name = policy.name.lower()
        if handler_name == "formatrule":
            return self._format_rule(policy, preprocessed, signals)
        if handler_name == "hallucinationguard":
            return self._hallucination_guard(policy, preprocessed, signals)
        if handler_name == "promptleakprobe":
            return self._prompt_leak_probe(policy, preprocessed, signals)
        if handler_name == "piiscrubber":
            return self._pii_scrubber(policy, preprocessed, signals)
        if handler_name == "toxicitythrottle":
            return self._toxicity_throttle(policy, preprocessed, signals)
        if handler_name == "contextanchor":
            return self._context_anchor(policy, preprocessed, signals)
        if handler_name == "ratelimiter":
            return self._rate_limiter(policy, context, preprocessed, signals)
        if handler_name == "compliancevault":
            return self._compliance_vault(policy, preprocessed, signals)
        if handler_name == "biasscanner":
            return self._bias_scanner(policy, preprocessed, signals)
        if handler_name == "payloadsanitizer":
            return self._payload_sanitizer(policy, preprocessed, signals)
        return self._default(policy, preprocessed, signals)

    def _default(self, policy: Policy, preprocessed: PreprocessedContext, signals: SignalBundle) -> EvaluationResult:
        return EvaluationResult(
            policy_id=policy.policy_id,
            policy_name=policy.name,
            passed=True,
            score=0.5,
            severity=policy.severity,
            suggested_outcome=policy.default_outcome,
            message="No handler registered; default pass.",
            evidence={"rule_key": policy.rule_key},
            details={"policy_type": policy.policy_type.value},
        )

    def _format_rule(self, policy: Policy, preprocessed: PreprocessedContext, signals: SignalBundle) -> EvaluationResult:
        required_formats = [str(fmt).lower() for fmt in policy.parameters.get("required_formats", [])]
        requested = (preprocessed.requested_format or "").lower()
        hint = (preprocessed.format_hint or "").lower()
        min_structure_score = float(policy.parameters.get("min_structure_score", 0.95))
        score = signals.structure_score
        if required_formats:
            matches = [fmt for fmt in required_formats if fmt in {requested, hint}]
            if matches:
                score = max(score, 1.0)
            else:
                score = min(score, 0.0)
        passed = score >= min_structure_score
        return self._build_result(
            policy,
            passed=passed,
            score=score,
            message="Output format check passed." if passed else "Output format mismatch.",
            evidence={
                "required_formats": required_formats,
                "requested_format": preprocessed.requested_format,
                "format_hint": preprocessed.format_hint,
                "structure_score": signals.structure_score,
            },
        )

    def _hallucination_guard(self, policy: Policy, preprocessed: PreprocessedContext, signals: SignalBundle) -> EvaluationResult:
        confidence_threshold = float(policy.parameters.get("confidence_threshold", 0.82))
        max_uncertainty = float(policy.parameters.get("max_uncertainty", 0.18))
        support = signals.factual_support_score
        uncertainty = 1.0 - support
        passed = support >= confidence_threshold and uncertainty <= max_uncertainty
        return self._build_result(
            policy,
            passed=passed,
            score=support,
            message="Claims remain grounded." if passed else "Low grounding confidence detected.",
            evidence={
                "confidence_threshold": confidence_threshold,
                "max_uncertainty": max_uncertainty,
                "support": support,
                "uncertainty": uncertainty,
            },
        )

    def _prompt_leak_probe(self, policy: Policy, preprocessed: PreprocessedContext, signals: SignalBundle) -> EvaluationResult:
        threshold = float(policy.parameters.get("suspicious_pattern_threshold", 0.5))
        matches = signals.evidence.get("prompt_leak_matches", [])
        score = signals.prompt_leak_score
        passed = len(matches) == 0 and score >= threshold
        if matches:
            score = min(score, 0.0)
        return self._build_result(
            policy,
            passed=passed,
            score=score,
            message="No prompt leakage detected." if passed else "Prompt leakage indicators found.",
            evidence={"matches": matches, "threshold": threshold},
        )

    def _pii_scrubber(self, policy: Policy, preprocessed: PreprocessedContext, signals: SignalBundle) -> EvaluationResult:
        mask_before_persist = bool(policy.parameters.get("mask_before_persist", True))
        matches = signals.evidence.get("pii_matches", [])
        score = signals.pii_score
        passed = len(matches) == 0 and score >= 1.0 or (mask_before_persist and len(matches) == 0)
        if matches:
            score = min(score, 0.0)
        return self._build_result(
            policy,
            passed=passed,
            score=score,
            message="PII not detected." if passed else "PII detected in payload.",
            evidence={"matches": matches, "mask_before_persist": mask_before_persist},
        )

    def _toxicity_throttle(self, policy: Policy, preprocessed: PreprocessedContext, signals: SignalBundle) -> EvaluationResult:
        threshold = float(policy.parameters.get("toxicity_threshold", 0.45))
        score = signals.toxicity_score
        passed = score >= max(0.0, 1.0 - threshold)
        return self._build_result(
            policy,
            passed=passed,
            score=score,
            message="Toxicity below threshold." if passed else "Toxicity throttle triggered.",
            evidence={"toxicity_threshold": threshold, "toxicity_score": score, "hits": signals.evidence.get("toxicity_hits", 0)},
        )

    def _context_anchor(self, policy: Policy, preprocessed: PreprocessedContext, signals: SignalBundle) -> EvaluationResult:
        threshold = float(policy.parameters.get("semantic_alignment_threshold", 0.80))
        score = signals.context_alignment_score
        passed = score >= threshold
        return self._build_result(
            policy,
            passed=passed,
            score=score,
            message="Context remains anchored." if passed else "Context drift detected.",
            evidence={"semantic_alignment_threshold": threshold, "context_alignment": score},
        )

    def _rate_limiter(
        self,
        policy: Policy,
        context: EvaluationContext,
        preprocessed: PreprocessedContext,
        signals: SignalBundle,
    ) -> EvaluationResult:
        max_requests = int(policy.parameters.get("max_requests_per_minute", 60))
        max_tokens = int(policy.parameters.get("max_tokens_per_turn", 4096))
        rpm = int(context.metadata.get("requests_per_minute", 0) or 0)
        tokens = context.token_usage.get("total", preprocessed.total_tokens)
        passed = rpm <= max_requests and tokens <= max_tokens
        score = 1.0 if passed else max(0.0, min(max_requests / max(rpm, 1), max_tokens / max(tokens, 1)))
        return self._build_result(
            policy,
            passed=passed,
            score=score,
            message="Rate limits respected." if passed else "Rate limiter triggered.",
            evidence={"max_requests_per_minute": max_requests, "max_tokens_per_turn": max_tokens, "rpm": rpm, "tokens": tokens},
        )

    def _compliance_vault(self, policy: Policy, preprocessed: PreprocessedContext, signals: SignalBundle) -> EvaluationResult:
        frameworks = [str(item) for item in policy.parameters.get("compliance_frameworks", [])]
        immutable_audit = bool(policy.parameters.get("immutable_audit", True))
        score = signals.compliance_score
        passed = score >= 1.0 and immutable_audit and bool(frameworks)
        return self._build_result(
            policy,
            passed=passed,
            score=score,
            message="Compliance trail present." if passed else "Compliance trail incomplete.",
            evidence={"frameworks": frameworks, "immutable_audit": immutable_audit, "audit_score": score},
        )

    def _bias_scanner(self, policy: Policy, preprocessed: PreprocessedContext, signals: SignalBundle) -> EvaluationResult:
        threshold = float(policy.parameters.get("fairness_threshold", 0.96))
        score = signals.bias_score
        passed = score >= threshold
        return self._build_result(
            policy,
            passed=passed,
            score=score,
            message="No bias flagged." if passed else "Bias scanner flagged risky phrasing.",
            evidence={"fairness_threshold": threshold, "bias_score": score, "hits": signals.evidence.get("bias_hits", 0)},
        )

    def _payload_sanitizer(self, policy: Policy, preprocessed: PreprocessedContext, signals: SignalBundle) -> EvaluationResult:
        strip_code_blocks = bool(policy.parameters.get("strip_code_blocks", True))
        strip_injection_patterns = bool(policy.parameters.get("strip_injection_patterns", True))
        score = signals.payload_safety_score
        passed = score >= 1.0 or (strip_code_blocks and strip_injection_patterns and score >= 0.2)
        return self._build_result(
            policy,
            passed=passed,
            score=score,
            message="Payload is sanitized." if passed else "Unsafe payload content detected.",
            evidence={
                "code_block_count": preprocessed.code_block_count,
                "strip_code_blocks": strip_code_blocks,
                "strip_injection_patterns": strip_injection_patterns,
            },
        )

    def _build_result(
        self,
        policy: Policy,
        *,
        passed: bool,
        score: float,
        message: str,
        evidence: dict[str, Any],
    ) -> EvaluationResult:
        score = max(0.0, min(1.0, score))
        if policy.policy_type == PolicyType.HARD and not passed:
            suggested = policy.default_outcome if policy.default_outcome in {Outcome.BLOCK, Outcome.REJECT} else Outcome.BLOCK
        elif passed:
            suggested = Outcome.ACCEPT
        else:
            suggested = policy.default_outcome
            if policy.severity in {Severity.CRITICAL, Severity.HIGH} and suggested == Outcome.ACCEPT:
                suggested = Outcome.REJECT
        return EvaluationResult(
            policy_id=policy.policy_id,
            policy_name=policy.name,
            passed=passed,
            score=score,
            severity=policy.severity,
            suggested_outcome=suggested,
            message=message,
            evidence=evidence,
            details={
                "rule_key": policy.rule_key,
                "policy_type": policy.policy_type.value,
                "priority": policy.priority,
            },
        )
