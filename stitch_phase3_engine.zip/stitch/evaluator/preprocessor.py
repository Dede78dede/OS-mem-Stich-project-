from __future__ import annotations

import re
from typing import Any, Iterable

from .models import PreprocessedContext

_SECTION_RE = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)
_CODE_BLOCK_RE = re.compile(r"```.*?```", re.DOTALL)


def _normalize(text: str | None) -> str:
    if not text:
        return ""
    return " ".join(text.strip().split())


def _token_count(text: str) -> int:
    if not text:
        return 0
    return len(text.split())


def _extract_sections(text: str) -> list[str]:
    sections = [match.group(2).strip() for match in _SECTION_RE.finditer(text)]
    return sections


def _extract_claims(text: str) -> list[str]:
    candidates = re.split(r"(?<=[.!?])\s+", text)
    claims = [candidate.strip() for candidate in candidates if candidate.strip()]
    return claims


def _detect_format(text: str) -> str | None:
    stripped = text.strip()
    if not stripped:
        return None
    if stripped.startswith("{") and stripped.endswith("}"):
        return "json"
    if stripped.startswith("[") and stripped.endswith("]"):
        return "json"
    if stripped.startswith("<") and stripped.endswith(">"):
        return "xml"
    return None


def preprocess(
    user_input: str,
    llm_output: str | None,
    *,
    system_prompt: str = "",
    retrieved_memory_texts: Iterable[str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> PreprocessedContext:
    metadata = dict(metadata or {})
    memory_texts = list(retrieved_memory_texts or [])
    normalized_user_input = _normalize(user_input)
    normalized_output = _normalize(llm_output)
    normalized_prompt = _normalize(system_prompt)
    joined_memory = " ".join(_normalize(text) for text in memory_texts)

    sections = _extract_sections(llm_output or "")
    claims = _extract_claims(llm_output or "")
    code_block_count = len(_CODE_BLOCK_RE.findall(llm_output or ""))
    requested_format = metadata.get("expected_format") or metadata.get("requested_format")
    format_hint = _detect_format(llm_output or "")
    total_tokens = (
        _token_count(normalized_user_input)
        + _token_count(normalized_output)
        + _token_count(normalized_prompt)
        + _token_count(joined_memory)
    )

    return PreprocessedContext(
        normalized_user_input=normalized_user_input,
        normalized_llm_output=normalized_output,
        user_input_tokens=_token_count(normalized_user_input),
        llm_output_tokens=_token_count(normalized_output),
        system_prompt_tokens=_token_count(normalized_prompt),
        memory_tokens=_token_count(joined_memory),
        total_tokens=total_tokens,
        section_count=len(sections),
        claim_count=len(claims),
        code_block_count=code_block_count,
        format_hint=format_hint,
        requested_format=requested_format,
        sections=sections,
        claims=claims,
        metadata=metadata,
    )


class Preprocessor:
    """Facade for preprocessing raw Stitch evaluation inputs."""

    def preprocess(
        self,
        user_input: str,
        llm_output: str | None,
        *,
        system_prompt: str = "",
        retrieved_memory_texts: Iterable[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> PreprocessedContext:
        return preprocess(
            user_input,
            llm_output,
            system_prompt=system_prompt,
            retrieved_memory_texts=retrieved_memory_texts,
            metadata=metadata,
        )
