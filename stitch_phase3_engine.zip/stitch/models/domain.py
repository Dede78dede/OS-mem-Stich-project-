from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4

from pydantic import Field, field_validator, model_validator

from .base import StitchModel, utc_now


class MemoryLayer(str, Enum):
    HOT = "HOT"
    WARM = "WARM"
    COLD = "COLD"


class MemoryRecord(StitchModel):
    memory_id: UUID = Field(default_factory=uuid4)
    tenant_id: str
    user_id: str
    agent_id: str
    content: str | Dict[str, Any]
    layer: MemoryLayer = MemoryLayer.WARM
    version: int = Field(default=1, ge=1)
    immutable: bool = True
    merkle_hash: str | None = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)
    expires_at: datetime | None = None

    @field_validator("version")
    @classmethod
    def _validate_version(cls, value: int) -> int:
        if value < 1:
            raise ValueError("version must be >= 1")
        return value


class Agent(StitchModel):
    agent_id: UUID = Field(default_factory=uuid4)
    sovereign_id: str
    name: str
    role: str
    capabilities: List[str] = Field(default_factory=list)
    enabled: bool = True
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)


class ContextWindow(StitchModel):
    window_id: UUID = Field(default_factory=uuid4)
    agent_id: UUID
    memory_ids: List[UUID] = Field(default_factory=list)
    source_layers: List[MemoryLayer] = Field(default_factory=list)
    token_budget: int = Field(default=256_000, ge=1)
    current_tokens: int = Field(default=0, ge=0)
    priority: int = Field(default=0, ge=0)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)

    @model_validator(mode="after")
    def _validate_budget(self) -> "ContextWindow":
        if self.current_tokens > self.token_budget:
            raise ValueError("current_tokens cannot exceed token_budget")
        return self


class AuditEvent(StitchModel):
    event_id: UUID = Field(default_factory=uuid4)
    event_type: str
    timestamp: datetime = Field(default_factory=utc_now)
    actor_agent_id: UUID | None = None
    memory_id: UUID | None = None
    prev_event_hash: str | None = None
    event_hash: str | None = None
    signature: str | None = None
    payload: Dict[str, Any] = Field(default_factory=dict)

