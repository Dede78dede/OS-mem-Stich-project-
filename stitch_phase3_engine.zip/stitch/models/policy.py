from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Dict, List
from uuid import UUID, uuid4

from pydantic import Field, field_validator, model_validator

from .base import StitchModel, utc_now
from .enums import Outcome, PolicyCategory, PolicyType, Severity

_SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$")


def _slugify(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", value.strip().lower()).strip("_")
    return slug or "policy"


class Policy(StitchModel):
    policy_id: UUID = Field(default_factory=uuid4)
    name: str
    slug: str | None = None
    version: str = Field(default="1.0.0")
    category: PolicyCategory
    policy_type: PolicyType
    severity: Severity
    enabled: bool = True
    description: str = ""
    rationale: str = ""
    rule_key: str
    default_outcome: Outcome = Outcome.REJECT
    priority: int = Field(default=100, ge=0)
    parameters: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)
    source_ref: str | None = None
    created_at: datetime = Field(default_factory=utc_now)
    updated_at: datetime = Field(default_factory=utc_now)

    @field_validator("version")
    @classmethod
    def _validate_version(cls, value: str) -> str:
        if not _SEMVER_RE.match(value):
            raise ValueError("version must be SemVer-like (e.g. 1.0.4)")
        return value

    @model_validator(mode="after")
    def _populate_slug(self) -> "Policy":
        if not self.slug:
            self.slug = _slugify(self.name)
        return self

    def touch(self) -> None:
        self.updated_at = utc_now()

    def enable(self) -> None:
        self.enabled = True
        self.touch()

    def disable(self) -> None:
        self.enabled = False
        self.touch()


class PolicyMetrics(StitchModel):
    policy_id: UUID
    policy_name: str
    total_evaluations: int = Field(default=0, ge=0)
    total_passed: int = Field(default=0, ge=0)
    total_failed: int = Field(default=0, ge=0)
    success_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    failure_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    avg_score: float = Field(default=0.0, ge=0.0, le=1.0)
    last_evaluated_at: datetime | None = None
    last_failure_at: datetime | None = None
    last_score: float | None = Field(default=None, ge=0.0, le=1.0)
    last_outcome: Outcome | None = None

    def record(self, score: float, passed: bool, outcome: Outcome | None = None) -> None:
        if score < 0.0 or score > 1.0:
            raise ValueError("score must be in [0.0, 1.0]")

        previous_total = self.total_evaluations
        self.total_evaluations += 1
        self.last_evaluated_at = utc_now()
        self.last_score = score
        self.last_outcome = outcome

        if passed:
            self.total_passed += 1
        else:
            self.total_failed += 1
            self.last_failure_at = self.last_evaluated_at

        self.success_rate = self.total_passed / self.total_evaluations if self.total_evaluations else 0.0
        self.failure_rate = self.total_failed / self.total_evaluations if self.total_evaluations else 0.0
        if previous_total == 0:
            self.avg_score = score
        else:
            self.avg_score = ((self.avg_score * previous_total) + score) / self.total_evaluations
