from __future__ import annotations

from enum import Enum


class Severity(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class PolicyType(str, Enum):
    HARD = "HARD"
    SOFT = "SOFT"
    CONTEXT = "CONTEXT"
    EXECUTION = "EXECUTION"


class PolicyCategory(str, Enum):
    SAFETY = "SAFETY"
    QUALITY = "QUALITY"
    CONTEXT = "CONTEXT"
    EXECUTION = "EXECUTION"


class Outcome(str, Enum):
    ACCEPT = "ACCEPT"
    REFINE = "REFINE"
    REJECT = "REJECT"
    BLOCK = "BLOCK"
    ESCALATE = "ESCALATE"
