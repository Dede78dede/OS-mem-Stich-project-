from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List
from uuid import UUID, uuid4

from pydantic import Field, field_validator, model_validator

from .base import StitchModel, utc_now
from .enums import Outcome, Severity


class EvaluationContext(StitchModel):
    session_id: str
    user_input: str
    llm_output: str | None = None
    retrieved_memory_ids: List[UUID] = Field(default_factory=list)
    system_prompt: str = ""
    metadata: Dict[str, Any] = Field(default_factory=dict)
    token_usage: Dict[str, int] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)


class EvaluationResult(StitchModel):
    policy_id: UUID
    policy_name: str
    passed: bool
    score: float = Field(ge=0.0, le=1.0)
    severity: Severity
    suggested_outcome: Outcome = Outcome.REFINE
    message: str = ""
    evidence: Dict[str, Any] = Field(default_factory=dict)
    details: Dict[str, Any] = Field(default_factory=dict)
    evaluated_at: datetime = Field(default_factory=utc_now)

    @field_validator("score")
    @classmethod
    def _validate_score(cls, value: float) -> float:
        if not 0.0 <= value <= 1.0:
            raise ValueError("score must be in [0.0, 1.0]")
        return value


class EvaluationBatchResult(StitchModel):
    results: List[EvaluationResult] = Field(default_factory=list)
    global_score: float = Field(default=0.0, ge=0.0, le=1.0)
    policy_failures: List[UUID] = Field(default_factory=list)
    critical_failures: List[UUID] = Field(default_factory=list)
    evaluation_time_ms: int = Field(default=0, ge=0)
    computed_at: datetime = Field(default_factory=utc_now)


class Decision(StitchModel):
    decision_id: UUID = Field(default_factory=uuid4)
    outcome: Outcome
    confidence: float = Field(ge=0.0, le=1.0)
    reason: str
    violations: List[str] = Field(default_factory=list)
    retry_allowed: bool = False
    next_action: Dict[str, Any] = Field(default_factory=dict)
    diagnostics: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=utc_now)


class RuntimeState(StitchModel):
    session_id: str
    retry_count: int = Field(default=0, ge=0)
    max_retry: int = Field(default=2, ge=0)
    blocked: bool = False
    escalated: bool = False
    last_outcome: Outcome | None = None
    last_reason: str = ""
    updated_at: datetime = Field(default_factory=utc_now)

    @model_validator(mode="after")
    def _validate_retry_bounds(self) -> "RuntimeState":
        if self.retry_count > self.max_retry:
            raise ValueError("retry_count cannot exceed max_retry")
        return self




class EnforcementResult(StitchModel):
    session_id: str
    decision: Decision
    evaluation_results: List[EvaluationResult] = Field(default_factory=list)
    action_taken: str
    status: str
    message: str = ""
    audit_ref: str | None = None
    runtime_state: RuntimeState | None = None
    created_at: datetime = Field(default_factory=utc_now)

class EnforcementReport(StitchModel):
    report_id: UUID = Field(default_factory=uuid4)
    session_id: str
    decision: Decision
    evaluation_results: List[EvaluationResult] = Field(default_factory=list)
    action_taken: str
    status: str
    message: str = ""
    audit_ref: str | None = None
    runtime_state: RuntimeState | None = None
    created_at: datetime = Field(default_factory=utc_now)
