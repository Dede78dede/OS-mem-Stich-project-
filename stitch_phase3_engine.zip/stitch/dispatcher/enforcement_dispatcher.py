from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from ..models import Decision, EnforcementResult, EvaluationContext, Outcome, RuntimeState


@dataclass(slots=True)
class DispatcherSettings:
    max_retry: int = 2
    allow_retry_on_reject: bool = True
    enable_escalation: bool = True
    strict_mode: bool = False
    audit_level: str = "STANDARD"


class EnforcementDispatcher:
    """Deterministic execution layer for Stitch v1.0."""

    def __init__(self, settings: DispatcherSettings | None = None) -> None:
        self.settings = settings or DispatcherSettings()

    def dispatch(
        self,
        decision: Decision,
        context: EvaluationContext,
        runtime: RuntimeState | None = None,
        *,
        llm_output: Optional[str] = None,
    ) -> EnforcementResult:
        runtime_state = runtime or RuntimeState(session_id=context.session_id, max_retry=self.settings.max_retry)
        output = llm_output if llm_output is not None else context.llm_output

        try:
            if decision.outcome == Outcome.ACCEPT:
                next_state = self._update_runtime(runtime_state, action="ACCEPT", outcome=Outcome.ACCEPT)
                return EnforcementResult(
                    session_id=context.session_id,
                    decision=decision,
                    evaluation_results=[],
                    action_taken="ACCEPT",
                    status="PASSED",
                    message=decision.reason,
                    audit_ref=self._audit_ref(next_state),
                    runtime_state=next_state,
                )

            if decision.outcome == Outcome.REFINE:
                return self._handle_refine(decision, context, runtime_state)

            if decision.outcome == Outcome.REJECT:
                return self._handle_reject(decision, runtime_state)

            if decision.outcome == Outcome.BLOCK:
                return self._handle_block(decision, runtime_state)

            return self._handle_escalate(decision, runtime_state)

        except Exception as exc:
            next_state = self._update_runtime(runtime_state, action="FAIL_SAFE", outcome=Outcome.ESCALATE, blocked=True, escalated=True)
            return EnforcementResult(
                session_id=context.session_id,
                decision=decision,
                evaluation_results=[],
                action_taken="FAIL_SAFE",
                status="ESCALATED",
                message=f"Dispatcher failure: {exc.__class__.__name__}",
                audit_ref=self._audit_ref(next_state),
                runtime_state=next_state,
            )

    def _handle_refine(self, decision: Decision, context: EvaluationContext, runtime: RuntimeState) -> EnforcementResult:
        if runtime.retry_count >= min(runtime.max_retry, self.settings.max_retry):
            return self._handle_reject(decision, runtime, message="Retry limit reached.")

        next_state = self._update_runtime(runtime, action="REFINE", outcome=Outcome.REFINE, retry=True)
        hints = self._build_refine_hints(decision)
        return EnforcementResult(
            session_id=context.session_id,
            decision=decision,
            evaluation_results=[],
            action_taken="REFINE",
            status="RETRYING",
            message=hints,
            audit_ref=self._audit_ref(next_state),
            runtime_state=next_state,
        )

    def _handle_reject(self, decision: Decision, runtime: RuntimeState, message: str | None = None) -> EnforcementResult:
        retry_allowed = (
            self.settings.allow_retry_on_reject
            and decision.retry_allowed
            and runtime.retry_count < min(runtime.max_retry, self.settings.max_retry)
            and not self.settings.strict_mode
        )

        if retry_allowed:
            next_state = self._update_runtime(runtime, action="REJECT->RETRY", outcome=Outcome.REJECT, retry=True)
            return EnforcementResult(
                session_id=runtime.session_id,
                decision=decision,
                evaluation_results=[],
                action_taken="REJECT",
                status="RETRYING",
                message=message or decision.reason,
                audit_ref=self._audit_ref(next_state),
                runtime_state=next_state,
            )

        next_state = self._update_runtime(runtime, action="REJECT", outcome=Outcome.REJECT)
        return EnforcementResult(
            session_id=runtime.session_id,
            decision=decision,
            evaluation_results=[],
            action_taken="REJECT",
            status="REJECTED",
            message=message or decision.reason,
            audit_ref=self._audit_ref(next_state),
            runtime_state=next_state,
        )

    def _handle_block(self, decision: Decision, runtime: RuntimeState) -> EnforcementResult:
        next_state = self._update_runtime(runtime, action="BLOCK", outcome=Outcome.BLOCK, blocked=True)
        return EnforcementResult(
            session_id=runtime.session_id,
            decision=decision,
            evaluation_results=[],
            action_taken="BLOCK",
            status="BLOCKED",
            message=decision.reason,
            audit_ref=self._audit_ref(next_state),
            runtime_state=next_state,
        )

    def _handle_escalate(self, decision: Decision, runtime: RuntimeState) -> EnforcementResult:
        if not self.settings.enable_escalation:
            return self._handle_block(decision, runtime)
        next_state = self._update_runtime(runtime, action="ESCALATE", outcome=Outcome.ESCALATE, escalated=True)
        return EnforcementResult(
            session_id=runtime.session_id,
            decision=decision,
            evaluation_results=[],
            action_taken="ESCALATE",
            status="ESCALATED",
            message=decision.reason,
            audit_ref=self._audit_ref(next_state),
            runtime_state=next_state,
        )

    def _build_refine_hints(self, decision: Decision) -> str:
        issues = ", ".join(decision.violations) if decision.violations else "general quality"
        return f"Refine output. Fix: {issues}. Stay within scope and preserve format."

    def _update_runtime(
        self,
        runtime: RuntimeState,
        *,
        action: str,
        outcome: Outcome,
        retry: bool = False,
        blocked: bool | None = None,
        escalated: bool | None = None,
    ) -> RuntimeState:
        return RuntimeState(
            session_id=runtime.session_id,
            retry_count=runtime.retry_count + (1 if retry else 0),
            max_retry=runtime.max_retry,
            blocked=runtime.blocked if blocked is None else blocked,
            escalated=runtime.escalated if escalated is None else escalated,
            last_outcome=outcome,
            last_reason=action,
            updated_at=datetime.now(timezone.utc),
        )

    def _audit_ref(self, runtime: RuntimeState) -> str:
        return f"{runtime.session_id}:{runtime.retry_count}:{int(runtime.updated_at.timestamp())}"
