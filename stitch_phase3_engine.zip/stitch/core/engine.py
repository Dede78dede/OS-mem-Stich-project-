from __future__ import annotations

from dataclasses import dataclass, field

from ..dispatcher import DispatcherSettings, EnforcementDispatcher
from ..evaluator import Evaluator, EvaluatorSettings
from ..models import EnforcementReport, EvaluationContext, RuntimeState
from ..registry import PolicyRegistry
from ..resolver import DecisionResolver, ResolverSettings


@dataclass(slots=True)
class EngineSettings:
    max_retry: int = 2
    strict_mode: bool = False
    allow_retry_on_reject: bool = True
    enable_escalation: bool = True


@dataclass
class StitchEngine:
    """End-to-end Stitch runtime: registry -> evaluator -> resolver -> dispatcher."""

    registry: PolicyRegistry = field(default_factory=PolicyRegistry.default)
    settings: EngineSettings = field(default_factory=EngineSettings)
    evaluator: Evaluator = field(init=False, repr=False)
    resolver: DecisionResolver = field(init=False, repr=False)
    dispatcher: EnforcementDispatcher = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self.evaluator = Evaluator(
            registry=self.registry,
            settings=EvaluatorSettings(),
        )
        self.resolver = DecisionResolver(
            ResolverSettings(
                max_retry=self.settings.max_retry,
                strict_mode=self.settings.strict_mode,
            )
        )
        self.dispatcher = EnforcementDispatcher(
            DispatcherSettings(
                max_retry=self.settings.max_retry,
                allow_retry_on_reject=self.settings.allow_retry_on_reject,
                enable_escalation=self.settings.enable_escalation,
                strict_mode=self.settings.strict_mode,
            )
        )

    def process(
        self,
        context: EvaluationContext,
        *,
        runtime_state: RuntimeState | None = None,
        llm_output: str | None = None,
    ) -> EnforcementReport:
        effective_context = context.model_copy(deep=True)
        if llm_output is not None:
            effective_context.llm_output = llm_output

        runtime = runtime_state or RuntimeState(session_id=effective_context.session_id, max_retry=self.settings.max_retry)
        batch = self.evaluator.evaluate(effective_context)
        decision = self.resolver.resolve(batch, retry_count=runtime.retry_count)
        dispatch_result = self.dispatcher.dispatch(
            decision,
            effective_context,
            runtime,
            llm_output=effective_context.llm_output,
        )
        return EnforcementReport(
            session_id=effective_context.session_id,
            decision=decision,
            evaluation_results=batch.results,
            action_taken=dispatch_result.action_taken,
            status=dispatch_result.status,
            message=dispatch_result.message,
            audit_ref=dispatch_result.audit_ref,
            runtime_state=dispatch_result.runtime_state,
        )
