from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from uuid import UUID

from ..models import Decision, EvaluationBatchResult, EvaluationResult, Outcome, Severity


@dataclass(slots=True)
class ResolverSettings:
    accept_threshold: float = 0.80
    refine_threshold: float = 0.60
    reject_threshold: float = 0.40
    max_retry: int = 2
    strict_mode: bool = False
    hard_block_policies: set[str] = field(
        default_factory=lambda: {
            "PromptLeakProbe",
            "PIIScrubber",
            "PayloadSanitizer",
            "ComplianceVault",
        }
    )


class DecisionResolver:
    """Deterministic decision resolver for Stitch v1.0."""

    def __init__(self, settings: ResolverSettings | None = None) -> None:
        self.settings = settings or ResolverSettings()

    def resolve(self, batch: EvaluationBatchResult, *, retry_count: int = 0) -> Decision:
        failed = [result for result in batch.results if not result.passed]
        failed_names = [result.policy_name for result in failed]
        critical_failures = [result.policy_name for result in failed if result.severity == Severity.CRITICAL]

        if self._has_hard_block(failed):
            return self._build_decision(
                outcome=Outcome.BLOCK,
                reason="Hard policy violation.",
                violations=failed_names,
                batch=batch,
                retry_count=retry_count,
                allow_retry=False,
            )

        if critical_failures:
            return self._build_decision(
                outcome=Outcome.REJECT,
                reason="Critical policy failure.",
                violations=critical_failures,
                batch=batch,
                retry_count=retry_count,
                allow_retry=self._can_retry(retry_count),
            )

        score = batch.global_score
        if score >= self.settings.accept_threshold:
            return self._build_decision(
                outcome=Outcome.ACCEPT,
                reason="High global score.",
                violations=[],
                batch=batch,
                retry_count=retry_count,
                allow_retry=False,
            )

        if score >= self.settings.refine_threshold:
            return self._build_decision(
                outcome=Outcome.REFINE,
                reason="Output needs refinement.",
                violations=failed_names,
                batch=batch,
                retry_count=retry_count,
                allow_retry=self._can_retry(retry_count),
            )

        if score >= self.settings.reject_threshold:
            return self._build_decision(
                outcome=Outcome.REJECT,
                reason="Output quality below acceptance threshold.",
                violations=failed_names,
                batch=batch,
                retry_count=retry_count,
                allow_retry=self._can_retry(retry_count),
            )

        return self._build_decision(
            outcome=Outcome.BLOCK if self.settings.strict_mode else Outcome.REJECT,
            reason="Global score too low.",
            violations=failed_names,
            batch=batch,
            retry_count=retry_count,
            allow_retry=False,
        )

    def _has_hard_block(self, failed: list[EvaluationResult]) -> bool:
        return any(result.policy_name in self.settings.hard_block_policies for result in failed)

    def _can_retry(self, retry_count: int) -> bool:
        return retry_count < self.settings.max_retry

    def _build_decision(
        self,
        *,
        outcome: Outcome,
        reason: str,
        violations: list[str],
        batch: EvaluationBatchResult,
        retry_count: int,
        allow_retry: bool,
    ) -> Decision:
        confidence = self._compute_confidence(batch)
        return Decision(
            outcome=outcome,
            confidence=confidence,
            reason=reason,
            violations=violations,
            retry_allowed=allow_retry,
            next_action=self._next_action(outcome, violations, retry_count),
            diagnostics=self._diagnostics(batch, retry_count),
        )

    def _compute_confidence(self, batch: EvaluationBatchResult) -> float:
        scores = [result.score for result in batch.results]
        if not scores:
            return 0.0
        average = sum(scores) / len(scores)
        variance = sum((score - average) ** 2 for score in scores) / len(scores)
        return max(0.0, min(1.0, 0.5 * average + 0.5 * (1.0 - variance)))

    def _next_action(self, outcome: Outcome, violations: list[str], retry_count: int) -> dict[str, Any]:
        if outcome == Outcome.ACCEPT:
            return {"type": "pass"}
        if outcome == Outcome.REFINE:
            return {"type": "retry", "retry_count": retry_count, "fix": violations}
        if outcome == Outcome.REJECT:
            return {"type": "review", "issues": violations}
        if outcome == Outcome.BLOCK:
            return {"type": "halt", "issues": violations}
        return {"type": "escalate", "issues": violations}

    def _diagnostics(self, batch: EvaluationBatchResult, retry_count: int) -> dict[str, Any]:
        failed = [result for result in batch.results if not result.passed]
        return {
            "global_score": batch.global_score,
            "policy_failures": [str(policy_id) for policy_id in batch.policy_failures],
            "critical_failures": [str(policy_id) for policy_id in batch.critical_failures],
            "failed_policies": [result.policy_name for result in failed],
            "retry_count": retry_count,
            "evaluation_time_ms": batch.evaluation_time_ms,
        }
