from __future__ import annotations

from collections import OrderedDict
from datetime import datetime
from threading import RLock
from typing import Iterable, List
from uuid import UUID

from pydantic import Field

from ..catalog import build_default_policies
from ..models import EvaluationResult, Policy, PolicyCategory, PolicyMetrics, PolicyType, Severity
from ..models.base import StitchModel, utc_now


class PolicyRegistryState(StitchModel):
    registry_version: str = "v2.0.0"
    policy_count: int = 0
    active_policy_count: int = 0
    policies: list[Policy] = Field(default_factory=list)
    metrics: list[PolicyMetrics] = Field(default_factory=list)
    updated_at: datetime = Field(default_factory=utc_now)


class PolicyRegistry:
    """Single source of truth for Stitch policy definitions and runtime metrics."""

    def __init__(self, policies: Iterable[Policy] | None = None, registry_version: str = "v2.0.0") -> None:
        self._lock = RLock()
        self.registry_version = registry_version
        self._by_id: OrderedDict[UUID, Policy] = OrderedDict()
        self._by_name: dict[str, UUID] = {}
        self._by_slug: dict[str, UUID] = {}
        self._metrics: dict[UUID, PolicyMetrics] = {}

        initial_policies = list(policies) if policies is not None else build_default_policies()
        self.register_batch(initial_policies)

    @classmethod
    def default(cls) -> PolicyRegistry:
        return cls(build_default_policies())

    def register(self, policy: Policy) -> None:
        with self._lock:
            if policy.policy_id in self._by_id:
                raise ValueError(f"Policy ID already registered: {policy.policy_id}")
            if policy.name in self._by_name:
                raise ValueError(f"Policy name already registered: {policy.name}")
            if policy.slug and policy.slug in self._by_slug:
                raise ValueError(f"Policy slug already registered: {policy.slug}")

            self._by_id[policy.policy_id] = policy
            self._by_name[policy.name] = policy.policy_id
            self._by_slug[policy.slug or policy.name.lower()] = policy.policy_id
            self._metrics[policy.policy_id] = PolicyMetrics(
                policy_id=policy.policy_id,
                policy_name=policy.name,
            )

    def register_batch(self, policies: Iterable[Policy]) -> None:
        for policy in policies:
            self.register(policy)

    def get_policy(self, policy_id: UUID | str) -> Policy:
        key = UUID(str(policy_id)) if not isinstance(policy_id, UUID) else policy_id
        try:
            return self._by_id[key]
        except KeyError as exc:
            raise KeyError(f"Unknown policy_id: {policy_id}") from exc

    def get_by_name(self, name: str) -> Policy:
        try:
            policy_id = self._by_name[name]
        except KeyError as exc:
            raise KeyError(f"Unknown policy name: {name}") from exc
        return self.get_policy(policy_id)

    def get_by_slug(self, slug: str) -> Policy:
        try:
            policy_id = self._by_slug[slug]
        except KeyError as exc:
            raise KeyError(f"Unknown policy slug: {slug}") from exc
        return self.get_policy(policy_id)

    def get_active_policies(
        self,
        *,
        category: PolicyCategory | None = None,
        severity: Severity | None = None,
        policy_type: PolicyType | None = None,
        include_disabled: bool = False,
    ) -> List[Policy]:
        with self._lock:
            policies = list(self._by_id.values())
            filtered = [
                p
                for p in policies
                if (include_disabled or p.enabled)
                and (category is None or p.category == category)
                and (severity is None or p.severity == severity)
                and (policy_type is None or p.policy_type == policy_type)
            ]
            return sorted(filtered, key=lambda p: (p.priority, p.name))

    def get_by_category(self, category: PolicyCategory) -> List[Policy]:
        return self.get_active_policies(category=category, include_disabled=True)

    def get_by_severity(self, severity: Severity) -> List[Policy]:
        return self.get_active_policies(severity=severity, include_disabled=True)

    def enable_policy(self, policy_id: UUID | str) -> Policy:
        policy = self._resolve_policy(policy_id)
        policy.enable()
        return policy

    def disable_policy(self, policy_id: UUID | str) -> Policy:
        policy = self._resolve_policy(policy_id)
        policy.disable()
        return policy

    def update_metrics(self, policy_id: UUID | str, result: EvaluationResult) -> PolicyMetrics:
        policy = self._resolve_policy(policy_id)
        metrics = self._metrics[policy.policy_id]
        metrics.record(score=result.score, passed=result.passed, outcome=result.suggested_outcome)
        policy.touch()
        return metrics

    def export_state(self) -> PolicyRegistryState:
        active_policies = self.get_active_policies(include_disabled=True)
        metrics = [self._metrics[policy.policy_id] for policy in active_policies]
        return PolicyRegistryState(
            registry_version=self.registry_version,
            policy_count=len(active_policies),
            active_policy_count=len([policy for policy in active_policies if policy.enabled]),
            policies=active_policies,
            metrics=metrics,
        )

    def list_policies(self, *, include_disabled: bool = True) -> List[Policy]:
        return self.get_active_policies(include_disabled=include_disabled)

    def _resolve_policy(self, policy_id: UUID | str) -> Policy:
        if isinstance(policy_id, UUID):
            return self.get_policy(policy_id)
        if policy_id in self._by_name:
            return self.get_by_name(policy_id)
        if policy_id in self._by_slug:
            return self.get_by_slug(policy_id)
        return self.get_policy(policy_id)
